#!/bin/bash
#POST-ing question-data, because PUT-ing every object at paths like "/bmzi-questions/$id" would break the
#ordering of questions when binding the query results to *ngFor. Questions would by default be displayed in order of #alphabetically sorted $ids

#POST bmzi-questions
curl -X POST -d '{ "id" : "fitges1", "text": "Um mich in guter körperlicher Verfassung zu halten"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "fitges2", "text": "Vor allem um fit zu sein"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "fitges3", "text": "Vor allem aus gesundheitlichen Gründen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "figaus1", "text": "Um abzunehmen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "figaus2", "text": "Um mein Gewicht zu regulieren"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "figaus3", "text": "Wegen meiner Figur"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "kon1", "text": "Um mit anderen gesellig zusammen zu sein"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "kon2", "text": "Um etwas in einer Gruppe zu unternehmen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "kon3", "text": "Um dabei Freunde \/ Bekannte zu treffen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "kon4", "text": "Um dadurch neue Menschen kennen zu lernen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "kon5", "text": "Um durch den Sport neue Freunde zu gewinnen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "ablkat1", "text": "Um Ärger und Gereiztheit abzubauen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "ablkat2", "text": "Weil ich mich so von anderen Problemen ablenke"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "ablkat3", "text": "Um Stress abzubauen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "ablkat4", "text": "Um meine Gedanken im Kopf zu ordnen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "aktfre1", "text": "Um mich zu entspannen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "aktfre2", "text": "Vor allem aus Freude an der Bewegung"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "aktfre3", "text": "Um neue Energie zu tanken"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "wetlei1", "text": "Weil ich im Wettkampf aufblühe"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "wetlei2", "text": "Um mich mit anderen zu messen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "wetlei3", "text": "Um sportliche Ziele zu erreichen"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "wetlei4", "text": "Wegen des Nervenkitzels"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "aes1", "text": "Weil es mir Freude bereitet, die Schönheit der menschlichen Bewegung im Sport zu erleben"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';
curl -X POST -d '{ "id" : "aes2", "text": "Weil mir Sport die Möglichkeit für schöne Bewegungen bietet"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-questions.json';

#POST bmzi-introduction
curl -X PUT  -d '{ "explanatory_text" : "Jeder Mensch hat unterschiedliche Motive und Ziele was Sport und Bewegung betrifft. Dieser Test misst diese persönlichen Merkmale und ermittelt Deinen individuellen Sport-Typ.", "expected_duration_text" : "Bearbeitungszeit ca. 3 Minuten", "link_data": "http:\/\/www.zssw.unibe.ch\/befragungen\/sportberatung\/BMZI_klein.pdf","link_text":"Ich möchte mehr über den Test wissen!"}' 'https://bachelorthesis-29f1b.firebaseio.com/bmzi-introduction.json';

#eof
