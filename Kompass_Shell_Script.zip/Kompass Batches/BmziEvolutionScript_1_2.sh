####################################################################################################
#################################  courses  ########################################################
####################################################################################################

curl -X POST  -d '{ "name": "Krafttraining",
					"profilePic": "assets/img/speakers/bear.jpg",
    	            "about": "Bärenstark",
					"generalSportPreference":{
   		            	"kontakt_sportl" : true,
						"figurbew_aest" : false,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
       			   }' 'https://bachelorthesis-29f1b.firebaseio.com/courses.json';


curl -X POST  -d  '{
			        "name": "Lauftreff",
			        "profilePic": "assets/img/speakers/cheetah.jpg",
			        "about": "Vom Panda zum Puma",
   		            "generalSportPreference":{
						"kontakt_sportl" : false,
						"figurbew_aest" : true,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
        		   }' 'https://bachelorthesis-29f1b.firebaseio.com/courses.json';

				 

curl -X POST  -d '{
			         "name": "Yoga",
			         "profilePic": "assets/img/speakers/duck.jpg",
			         "about": "In der Ruhe liegt die Kraft",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : true,
						 "erholungssuch_fit" : false,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					 }
        		    }' 'https://bachelorthesis-29f1b.firebaseio.com/courses.json';

curl -X POST  -d '{
					 "name": "Boxen",
			         "profilePic": "assets/img/speakers/eagle.jpg",
			         "about": "Fitnessboxen und Wettkampfsport",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : false,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					 }
			       }' 'https://bachelorthesis-29f1b.firebaseio.com/courses.json';

curl -X POST  -d '{
					 "name": "Standardtanz",
			         "profilePic": "assets/img/speakers/elephant.jpg",
			         "about": "Standardtänze in netter Gesellschaft",
			         "generalSportPreference":{
						 "kontakt_sportl" : true,
					     "figurbew_aest" : true,
						 "aktiv_erhol" : true,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : true,
						 "gesundheits_figo" : true,
						 "fig_gesell" : true,
						 "fig_stressreg" : true, 
						 "erhol_sportl" : true
				    }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/courses.json';

####################################################################################################
############################  courses by sport-types  ##############################################
####################################################################################################

curl -X POST  -d '{
					 "name": "Boxen",
			         "profilePic": "assets/img/speakers/eagle.jpg",
			         "about": "Fitnessboxen und Wettkampfsport",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : false,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					  }
					}' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/kontakt_sportl.json';

curl -X POST  -d '{
					 "name": "Standardtanz",
			         "profilePic": "assets/img/speakers/elephant.jpg",
			         "about": "Standardtänze in netter Gesellschaft",
			         "generalSportPreference":{
						 "kontakt_sportl" : true,
					     "figurbew_aest" : true,
						 "aktiv_erhol" : true,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : true,
						 "gesundheits_figo" : true,
						 "fig_gesell" : true,
						 "fig_stressreg" : true, 
						 "erhol_sportl" : true
					  }
				   }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/kontakt_sportl.json';

####################################################################################################

curl -X POST  -d '{
					 "name": "Boxen",
			         "profilePic": "assets/img/speakers/eagle.jpg",
			         "about": "Fitnessboxen und Wettkampfsport",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : false,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					  }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/figurbew_aest.json';

curl -X POST  -d '{
				    "name": "Krafttraining",
					"profilePic": "assets/img/speakers/bear.jpg",
    	            "about": "Bärenstark",
					"generalSportPreference":{
   		            	"kontakt_sportl" : true,
						"figurbew_aest" : false,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/figurbew_aest.json';

####################################################################################################

curl -X POST  -d '{
				     "name": "Yoga",
			         "profilePic": "assets/img/speakers/duck.jpg",
			         "about": "In der Ruhe liegt die Kraft",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : true,
						 "erholungssuch_fit" : false,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					 }
				   }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/aktiv_erhol.json';

curl -X POST  -d '{
			        "name": "Lauftreff",
			        "profilePic": "assets/img/speakers/cheetah.jpg",
			        "about": "Vom Panda zum Puma",
   		            "generalSportPreference":{
						"kontakt_sportl" : false,
						"figurbew_aest" : true,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/aktiv_erhol.json';

####################################################################################################

curl -X POST  -d '{
			        "name": "Lauftreff",
			        "profilePic": "assets/img/speakers/cheetah.jpg",
			        "about": "Vom Panda zum Puma",
   		            "generalSportPreference":{
						"kontakt_sportl" : false,
						"figurbew_aest" : true,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/erholungssuch_fit.json';

####################################################################################################

curl -X POST  -d '{
					 "name": "Boxen",
			         "profilePic": "assets/img/speakers/eagle.jpg",
			         "about": "Fitnessboxen und Wettkampfsport",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : false,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
						} 
					}' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/zweckfrei_sportbeg.json';

curl -X POST  -d '{
			        "name": "Lauftreff",
			        "profilePic": "assets/img/speakers/cheetah.jpg",
			        "about": "Vom Panda zum Puma",
   		            "generalSportPreference":{
						"kontakt_sportl" : false,
						"figurbew_aest" : true,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/zweckfrei_sportbeg.json';

curl -X POST  -d '{
			         "name": "Yoga",
			         "profilePic": "assets/img/speakers/duck.jpg",
			         "about": "In der Ruhe liegt die Kraft",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : true,
						 "erholungssuch_fit" : false,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
	   				}
     			 }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/zweckfrei_sportbeg.json';

####################################################################################################

curl -X POST  -d '{
			         "name": "Yoga",
			         "profilePic": "assets/img/speakers/duck.jpg",
			         "about": "In der Ruhe liegt die Kraft",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : true,
						 "erholungssuch_fit" : false,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/gesundheits_figo.json';

curl -X POST  -d '{	   
						"name": "Krafttraining",
					    "profilePic": "assets/img/speakers/bear.jpg",
         	            "about": "Bärenstark",
	     				"generalSportPreference":{
   		            		"kontakt_sportl" : true,
							"figurbew_aest" : false,
							"aktiv_erhol" : false,
							"erholungssuch_fit" : false,
							"zweckfrei_sportbeg" : false,
							"gesundheits_figo" : false,
							"fig_gesell" : false,
							"fig_stressreg" : false, 
							"erhol_sportl" : false
						 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/gesundheits_figo.json';

####################################################################################################


curl -X POST  -d '{
			        "name": "Lauftreff",
			        "profilePic": "assets/img/speakers/cheetah.jpg",
			        "about": "Vom Panda zum Puma",
   		            "generalSportPreference":{
						"kontakt_sportl" : false,
						"figurbew_aest" : true,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/fig_gesell.json';

####################################################################################################

curl -X POST  -d '{
					 "name": "Boxen",
			         "profilePic": "assets/img/speakers/eagle.jpg",
			         "about": "Fitnessboxen und Wettkampfsport",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : false,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					}
   }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/fig_stressreg.json';

curl -X POST  -d '{
			        "name": "Lauftreff",
			        "profilePic": "assets/img/speakers/cheetah.jpg",
			        "about": "Vom Panda zum Puma",
   		            "generalSportPreference":{
						"kontakt_sportl" : false,
						"figurbew_aest" : true,
						"aktiv_erhol" : false,
						"erholungssuch_fit" : false,
						"zweckfrei_sportbeg" : false,
						"gesundheits_figo" : false,
						"fig_gesell" : false,
						"fig_stressreg" : false, 
						"erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/fig_stressreg.json';

####################################################################################################

curl -X POST  -d '{
					 "name": "Boxen",
			         "profilePic": "assets/img/speakers/eagle.jpg",
			         "about": "Fitnessboxen und Wettkampfsport",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : false,
						 "erholungssuch_fit" : true,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					}
 }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/erhol_sportl.json';

curl -X POST  -d '{
			         "name": "Yoga",
			         "profilePic": "assets/img/speakers/duck.jpg",
			         "about": "In der Ruhe liegt die Kraft",
			         "generalSportPreference":{
						 "kontakt_sportl" : false,
					     "figurbew_aest" : false,
						 "aktiv_erhol" : true,
						 "erholungssuch_fit" : false,
						 "zweckfrei_sportbeg" : false,
						 "gesundheits_figo" : false,
						 "fig_gesell" : false,
						 "fig_stressreg" : false, 
						 "erhol_sportl" : false
					 }
			      }' 'https://bachelorthesis-29f1b.firebaseio.com/sportTypes/erhol_sportl.json';

####################################################################################################
#eof

 



